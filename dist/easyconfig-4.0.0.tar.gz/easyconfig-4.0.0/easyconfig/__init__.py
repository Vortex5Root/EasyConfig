from typing  import Dict
from pathlib import Path

from .Objects import Config

class Config_Manager:

    main_path : Path
    configs : Dict[str, Config] = {}

    def __init__(self, main_directory_name : str):
        self.main_path = Path(main_directory_name)
        if not self.main_path.exists():
            self.main_path.mkdir()
        else:
            if not self.main_path.is_dir():
                raise Exception(f'{main_directory_name} is not a directory')
            self.load_configs()

    def new_config(self, config_name: str, sub_directory: str = None):
        if sub_directory is not None:
            path = self.main_path / sub_directory
            if not path.exists():
                path.mkdir()
            config = Config(path, config_name)
            config_name = sub_directory + '/' + config_name
        else:
            config = Config(self.main_path, config_name)
        self.configs[config_name] = config
        return config

    def load_configs(self):
        for file in self.main_path.iterdir():
            if file.is_file() and file.suffix == '.json':
                config = Config(self.main_path, file.name)
                config.load_config()
                self.configs[file.name] = config
    
    def save_configs(self):
        for key in self.configs:
            self.configs[key].save_config()
